// config.js
module.exports = {
    apiKeyGoogle: 'AIzaSyDLoR2wL9Rfb8O_1P_kXNKYA8NVq1HpPms',
    openAIKey: 'sk-proj-hgYNTw63DYocJ53W5UDiT3BlbkFJvNSQQPhCBgeBDqWcbpdp'
};
